#' Select markers using Manhattan Distance
#'
#' This function screens SNP loci by calculating Manhattan distances
#' to selecting markers.
#'
#' @param snp_X A data frame of SNP data where rows represent samples and columns represent markers.
#' @param train_sample_size An integer representing the size of the training sample.
#' @param multiple A numeric multiplier to determine the number of loci to be selected.
#' @return A vector of indices corresponding to the selected markers.
#' @export

originalLociScreen <- function(snp_X,train_sample_size,multiple){
  snp_X <- as.matrix(snp_X)
  snp_X_T <- t(snp_X)
  num_markers <- nrow(snp_X_T)
  argTrain <- c(1)
  argDrop <- c(1)
  k <- 1
  markerDrop <- 0
  selectNum <- train_sample_size * multiple
  dropRounds <- ceiling(num_markers / selectNum) - 1
  while (length(argTrain) < selectNum) {
    snp_block <- snp_X_T[k,, drop = FALSE]
    distArray <- proxy::dist(snp_block, snp_X_T, method = "manhattan")
    distArray_matrix <- as.matrix(t(distArray))
    distArray_DF <- as.data.frame(distArray_matrix)
    original_indices <- 1:nrow(distArray_DF)

    distArray_filtered <- distArray_DF[-argDrop, , drop = FALSE]
    id_max <- which.max(unlist(distArray_filtered))
    original_indices_filtered <- original_indices[-argDrop]
    id_max_absolute <- original_indices_filtered[id_max]

    argTrain <- c(argTrain, id_max_absolute)
    argDrop <- c(argDrop, id_max_absolute)

    for (p in 1:dropRounds) {
      if (markerDrop == num_markers - selectNum) {
        id_left <- setdiff(1:nrow(distArray_DF), argDrop)
        argTrain <- c(argTrain, id_left)
        break
      }
      new_disArray <- distArray_DF[-argDrop, , drop = FALSE]
      original_indices_new <- original_indices[-argDrop]

      id_min <- which.min(unlist(new_disArray))
      id_min_absolute <- original_indices_new[id_min]

      argDrop <- c(argDrop, id_min_absolute)
      markerDrop <- markerDrop + 1
    }
    k <- id_max_absolute
    print(length(argTrain))
  }
  return(argTrain)
}
