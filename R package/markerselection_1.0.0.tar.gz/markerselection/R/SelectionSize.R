#' Consistent rounding function
#'
#' @param x A numeric value
#' @return An integer
#' @noRd
consistentRound <- function(x) {
  return(floor(x + 0.5))
}



#' Calculate the sample size for marker selection
#'
#' @param snp_X A data frame of SNP data
#' @param nfolds An integer, the number of folds (default is 1)
#'
#' @return A numeric of the sample size
#' @export

selectionSize <- function(snp_X,nfolds = 1){
  if (nfolds == 1) {
    size <- nrow(snp_X)
  } else {
    raw_val <- nrow(snp_X) / nfolds * (nfolds - 1)
    size <- consistentRound(raw_val)
  }
  print(size)
  return(size)
}
