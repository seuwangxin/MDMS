#' Calculate the sample size for marker selection
#'
#' @param snp_X A data frame of SNP data
#' @param nfolds An integer, the number of folds (default is 1)
#'
#' @return A numeric of the sample size
#' @export

selectionSize <- function(snp_X,nfolds = 1){
  if (nfolds == 1) {
    size <- nrow(snp_X)
  } else {
    size <- round(nrow(snp_X) / nfolds * (nfolds - 1))
  }
  print(size)
  return(size)
}
