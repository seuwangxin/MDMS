#' Main function for marker selection
#'
#' @param snp_X A data frame of SNP data
#' @param nfolds An integer indicating the number of folds for cross-validation. If set to 1 (default), no folding is performed. If greater than 1, the data will be split into `nfolds` folds
#' @return A vector of indices corresponding to the selected markers
#' @export

select <- function(snp_X,nfolds = 1){
  cat(paste("nfolds:", nfolds))
  column_names <- colnames(snp_X)
  group_names <- sapply(column_names, getGroupName)
  sample_size <- selectionSize(snp_X,nfolds)
  if (any(sapply(group_names, is.null))) {
    multiple <- 20
    all_snp_screen <- originalLociScreen(snp_X, sample_size, multiple)

  } else {
    last_column_name <- column_names[length(column_names)]
    last_column_number <- as.integer(getGroupName(last_column_name))

    grouped_column_lists <- vector("list", last_column_number)

    for (col_name in column_names) {
      group_number <- as.integer(getGroupName(col_name))
      grouped_column_lists[[group_number]] <- c(grouped_column_lists[[group_number]], col_name)
    }

    all_snp_screen <- c()

    for (index in 1:last_column_number) {
      group_list <- grouped_column_lists[[index]]
      group_data <- snp_X[, group_list]
      multiple <- 20
      selectNum <- sample_size * multiple
      group_num <- (length(group_data) / length(snp_X)) * selectNum
      group_select_num <- floor(group_num)

      snp_screen <- lociScreen(group_data, group_select_num)

      for (col in snp_screen) {
        col_name <- colnames(group_data)[col]
        index_in_snp <- which(colnames(snp_X) == col_name)
        all_snp_screen <- c(all_snp_screen, index_in_snp)
      }
    }
  }
  return(all_snp_screen)
}
