#' Get group name from column name
#'
#' @param col_name A character string representing the column name
#' @return A group name or NULL
#' @export

getGroupName <- function(col_name) {
  match <- regexpr("^(chr?(\\d+))[_-]", col_name)
  if (match != -1) {
    return(sub("^(chr?(\\d+))[_-].*", "\\2", col_name))
  }
  match <- regexpr("^(\\d+)[_-]", col_name)
  if (match != -1) {
    return(sub("^(\\d+)[_-].*", "\\1", col_name))
  }

  return(NULL)
}
