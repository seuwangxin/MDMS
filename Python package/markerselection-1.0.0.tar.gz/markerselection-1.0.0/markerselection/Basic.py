# MarkerSelection/Basic.py
import re
import math
from .LociScreen import originalLociScreen, lociScreen

def getGroupName(col_name):
    match = re.match(r'(chr?(\d+))[_-]', col_name)
    if match:
        return match.group(2)
    match = re.match(r'(\d+)[_-]', col_name)
    if match:
        return match.group(1)
    return None

def selectionSize(snp_X, nfolds=1):
    if nfolds == 1:
        size = len(snp_X)
    else:
        size = round(len(snp_X) / nfolds * (nfolds - 1))
    return size

def select(snp_X,nfolds=1):
    print(f"nfolds: {nfolds}")
    column_names = snp_X.columns
    group_names = [getGroupName(col) for col in column_names]
    sample_size = selectionSize(snp_X,nfolds)
    print(f"sample_size: {sample_size}")
    if None in group_names:
        multiple = 20
        all_snp_screen = originalLociScreen(snp_X, sample_size, multiple)
    else:
        last_column_name = column_names[-1]
        last_column_number = int(getGroupName(last_column_name))
        grouped_column_lists = [[] for _ in range(last_column_number)]
        for col_name in column_names:
            group_number = int(getGroupName(col_name))
            grouped_column_lists[group_number - 1].append(col_name)

        all_snp_screen = []
        for index, group_list in enumerate(grouped_column_lists):
            group_data = snp_X[group_list]
            multiple = 20
            selectNum = sample_size * multiple
            group_num = len(group_data.columns) / len(snp_X.columns) * selectNum
            group_select_num = math.floor(group_num)
            snp_screen = lociScreen(group_data, group_select_num)

            for col in snp_screen:
                col_name = group_data.columns[col]
                index_in_snp = snp_X.columns.get_loc(col_name)
                all_snp_screen.append(index_in_snp)
    return all_snp_screen



