# MarkerSelection/LociScreen.py
import numpy as np
import pandas as pd
import math
from sklearn.metrics.pairwise import manhattan_distances

def lociScreen(snp_X,selectNum):
    snp_X = np.array(snp_X)
    snp_X_T=snp_X.T
    num_markers = len(snp_X_T)
    argTrain = [0]
    argDrop = [0]
    k = 0
    markerDrop = 0
    dropRounds = math.ceil(num_markers / selectNum) - 1
    while len(argTrain) < selectNum:
        snp_block = snp_X_T[k:k + 1, :]
        distArray = manhattan_distances(snp_block, snp_X_T)  # 曼哈顿距离
        distArray = pd.DataFrame(distArray).T
        id_max = distArray.drop(argDrop).idxmax().iloc[0]
        argTrain.append(id_max)
        argDrop.append(id_max)
        for p in range(dropRounds):
            if markerDrop == num_markers - selectNum:
                id_left = distArray.drop(argDrop).index
                id_left = list(id_left)
                argTrain.extend(id_left)
                break
            id_min = distArray.drop(argDrop).idxmin().iloc[0]
            argDrop.append(id_min)
            markerDrop += 1
        k = id_max
        print(len(argTrain))
    return argTrain

def originalLociScreen(snp_X,train_sample_size,multiple):
    snp_X = np.array(snp_X)
    snp_X_T=snp_X.T
    num_markers = len(snp_X_T)
    argTrain = [0]
    argDrop = [0]
    k = 0
    markerDrop = 0
    selectNum = train_sample_size * multiple
    dropRounds = math.ceil(num_markers / selectNum) - 1
    while len(argTrain) < selectNum:
        snp_block = snp_X_T[k:k + 1, :]
        distArray = manhattan_distances(snp_block, snp_X_T)  # 曼哈顿距离
        distArray = pd.DataFrame(distArray).T
        id_max = distArray.drop(argDrop).idxmax().iloc[0]
        argTrain.append(id_max)
        argDrop.append(id_max)
        for p in range(dropRounds):
            if markerDrop == num_markers - selectNum:
                id_left = distArray.drop(argDrop).index
                id_left = list(id_left)
                argTrain.extend(id_left)
                break
            id_min = distArray.drop(argDrop).idxmin().iloc[0]
            argDrop.append(id_min)
            markerDrop += 1
        k = id_max
        print(len(argTrain))
    return argTrain