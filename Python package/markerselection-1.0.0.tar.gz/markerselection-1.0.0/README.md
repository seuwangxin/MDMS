# SNP Processing Package

This is a Python package to selecting mark for SNP (Single Nucleotide Polymorphism) loci data.

## Installation

You can install the package using pip:

```bash
pip install MarkerSelection

## Usage

Here's an example of how to use the package:

```python
from MarkerSelection import markerSelection

result = markerSelection(snp,nfolds)