# SNP Marker Selection Package

A Python package designed for selecting markers from SNP (Single Nucleotide Polymorphism) data.

## Installation

You can install the package using pip:

```bash
pip install markerselection

## Usage

Here's an example of how to use the package:

```python
from markerselection import select

result = select(snp,nfolds,multiple)