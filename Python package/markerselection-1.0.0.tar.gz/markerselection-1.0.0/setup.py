from setuptools import setup, find_packages

setup(
    name='markerselection',
    version='1.0.0',
    author="Xin Wang, Yu Wang, Yang Xu, Chenwu Xu",
    description='A package for Manhattan distance-based marker selection',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'pandas',
        'scikit-learn',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',

)
